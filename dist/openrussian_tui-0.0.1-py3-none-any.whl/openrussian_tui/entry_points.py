from openrussian_tui.openrussian import OpenRussian


def openrussian():
    app = OpenRussian()
    app.run()
