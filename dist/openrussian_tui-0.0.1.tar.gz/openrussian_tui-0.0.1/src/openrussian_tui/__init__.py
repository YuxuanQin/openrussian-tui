# SPDX-FileCopyrightText: 2026-present qinyx-endeavour <oreo_queen@outlook.com>
#
# SPDX-License-Identifier: MIT
