# openrussian-tui

[![PyPI - Version](https://img.shields.io/pypi/v/openrussian-tui.svg)](https://pypi.org/project/openrussian-tui)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/openrussian-tui.svg)](https://pypi.org/project/openrussian-tui)

-----

## Table of Contents

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install openrussian-tui
```

## License

`openrussian-tui` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
